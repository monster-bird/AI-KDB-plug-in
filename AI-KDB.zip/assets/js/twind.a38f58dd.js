import{o as t}from"./client.8498815c.js";function o(){t({preflight:!1,hash:!0})}export{o as t};
